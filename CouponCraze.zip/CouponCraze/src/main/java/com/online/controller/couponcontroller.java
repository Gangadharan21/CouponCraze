package com.online.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.online.entity.checkout;
import com.online.entity.coupon;
import com.online.entity.mycouponlist;
import com.online.service.checkoutservice;
import com.online.service.couponservice;
import com.online.service.loginservice;
import com.online.service.mycouponlistservice;


@Controller
public class couponcontroller {
	
	@Autowired
	private couponservice Service;
	
	@Autowired
	private mycouponlistservice Mycouponservice;
	
	@Autowired
	private loginservice Loginservice;
	
	@Autowired
	checkoutservice objcheck;
	
		
	@GetMapping("/signup")
	public ModelAndView loginsave(@RequestParam("username")		
	String username,@RequestParam("password") String password)
	{
		Loginservice.usersave(username,password);
		ModelAndView objmv = new ModelAndView();
		objmv.setViewName("/registersuccess");		
		return objmv;

	}
	
	@PostMapping("/loginpm")
	public ModelAndView login(@RequestParam("username") String username, 
	                          @RequestParam("password") String password) {
	    ModelAndView modelAndView = new ModelAndView();
	    
	    if (Loginservice.validateUser(username, password)) {
	        modelAndView.setViewName("home"); // Redirect to main page if login is successful
	    } else {
	        modelAndView.setViewName("errorlogin"); // Redirect back to login page if authentication fails
	        modelAndView.addObject("error", "Invalid username or password");
	    }
	    
	    return modelAndView;
	}
	
	@GetMapping("/cart")
	public ModelAndView buynow(checkout b)
	{
		objcheck.save(b);
		ModelAndView objmv=new ModelAndView();
		objmv.setViewName("placeorder");
		
		checkout objcheck=new checkout();
		
		objmv.addObject("place", objcheck);
		return objmv;
		
	}
	@GetMapping("/")
	public String registerpage()
	{
		return "register";
	}	
	
	@GetMapping("/login")
    public String loginPage() {
        return "loginpage";
    }
	
	
	@GetMapping("/success")
	public String registers() {
		return "registersuccess";
	}

	@GetMapping("/admin")
	public String adminlogin() {
		return "admin";		
	}
	
	
	@GetMapping("/couponreg")
	public String couponr() {
		return "couponregister";
		
	}
	
	@GetMapping("/home1")
	public String home() {	
		return "home";
	}
	
	@GetMapping("/contact")
	public String contactus() {
		return "contactus";
	}
	
	@GetMapping("/erroradmin")
	public String erroradmin() {
		return "erroradmin";
	}
	
	@GetMapping("/checkout")
	public String checkout()
	{
		return "checkout";
	}
	
	@GetMapping("/available_coupon")
	public ModelAndView getAllCoupon() {
		List<coupon>list=Service.getAllCoupon();
		return new ModelAndView("couponlist", "coupon", list);
	
	}
	
	@PostMapping("/save")
	public String addcoupon(@ModelAttribute coupon b) {
		Service.save(b);
		return "redirect:/available_coupon";
	}
	
	@GetMapping("/my_coupons")
	public String getMyCoupons(Model model) {
		List<mycouponlist>list=Mycouponservice.getAllMyCoupon();
		model.addAttribute("coupon",list);
		return "mycoupon";
	}
	
	@RequestMapping("/mylist/{id}")
	public String getmylist(@PathVariable("id") int id) {
		coupon b=Service.getCouponById(id);
		mycouponlist mb=new mycouponlist(b.getId(),b.getName(),b.getCouponcode(),b.getPrice());
		Mycouponservice.SaveMyCoupon(mb);
		return "redirect:/my_coupons";
	}
	
	@RequestMapping("/editcoupon/{id}")
	public String editcoupon(@PathVariable("id") int id, Model model) {
		coupon b=Service.getCouponById(id);
		model.addAttribute("coupon", b);
		return "couponEdit";
	}
	
	@RequestMapping("/deletecoupon/{id}")
	public String deletecoupon(@PathVariable("id") int id) {
		Service.deleteById(id);
		return "redirect:/available_coupon";
	}

}
