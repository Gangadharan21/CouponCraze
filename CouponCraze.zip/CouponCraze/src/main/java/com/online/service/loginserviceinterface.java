package com.online.service;

import com.online.entity.login;

public interface loginserviceinterface {
	public login usersave (String username, String password);
	

}
