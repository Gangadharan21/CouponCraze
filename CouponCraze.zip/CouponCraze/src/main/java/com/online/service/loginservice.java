package com.online.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.entity.login;
import com.online.repository.loginrepository;


@Service
public class loginservice implements loginserviceinterface{
	
	@Autowired
	private loginrepository servicelogin;
	
	
	
	@Override
	public login usersave (String username, String password) {
		login coulogin = new login();
		coulogin.setUsername(username);
		coulogin.setPassword(password);
		return servicelogin.save(coulogin);
	}
	
	 public boolean validateUser(String username, String password) {
	        Optional<login> user = servicelogin.findByUsername(username);
	        if (user.isPresent() && user.get().getPassword().equals(password)) {
	            return true;
	        }
	        return false;
	    }
	}
