package com.online.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.entity.mycouponlist;
import com.online.repository.mycouponrepository;

@Service
public class mycouponlistservice{
	
	@Autowired
	private mycouponrepository mycoupon;
	
	public void SaveMyCoupon( mycouponlist coupon) {
		mycoupon.save(coupon);
	}
	
	public List<mycouponlist> getAllMyCoupon(){
		return mycoupon.findAll();
	}
	
	public void deleteById(int id) {
		mycoupon.deleteById(id);
	}

}
