package com.online.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.entity.coupon;
import com.online.repository.couponrepository;

@Service
public class couponservice {
	
	@Autowired
	private couponrepository brepo;
	
	public void save(coupon b){
		brepo.save(b);
	}
	
	public List<coupon> getAllCoupon(){
		return brepo.findAll();
	}
	
	public coupon getCouponById(int id) {
		return brepo.findById(id).get();
		
	}
	
	public void deleteById(int id) {
		brepo.deleteById(id);
	}
	

}
