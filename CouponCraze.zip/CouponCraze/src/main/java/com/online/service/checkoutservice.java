package com.online.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.entity.checkout;
import com.online.repository.checkoutrepository;

@Service
public class checkoutservice implements checkoutserviceinterface{
	
	@Autowired
	checkoutrepository objcheckout;
		

	@Override
	public void save(checkout b) {
		// TODO Auto-generated method stub
		objcheckout.save(b);
	}

	
	

}
