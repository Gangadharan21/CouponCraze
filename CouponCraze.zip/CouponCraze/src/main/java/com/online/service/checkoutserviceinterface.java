package com.online.service;

import com.online.entity.checkout;

public interface checkoutserviceinterface {
	
	public void save(checkout b);
	
 
}
