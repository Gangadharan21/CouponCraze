package com.online.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.online.entity.checkout;

public interface checkoutrepository extends JpaRepository<checkout,Integer> {

	
}
