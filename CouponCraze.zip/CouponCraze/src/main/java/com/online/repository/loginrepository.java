package com.online.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.online.entity.login;

@Repository
public interface loginrepository extends JpaRepository<login,Integer>{
	
	Optional<login> findByUsername(String username);
	

}
